<?php
    $product_id = $_POST['product_id'];
    $product_price = $_POST['product_price'];
    if (isset($_POST['product_id']) && isset($_POST['product_price'])) {
        $product_id = $_POST['product_id'];
        $product_price = $_POST['product_price'];
    } else {
        echo "Product information is missing.";
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Form</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        *{
            box-sizing: border-box;
        }

        body{
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .side {
            height: 100vh;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-y: auto;
            padding-top: 20px;
        }
        .left {
            left: 0;
            background-color: #ffffff;
            border-right: 1px solid #ccc

        }
        .right {
            right: 0;
            background-color:#d5d4d4;
            color: white;
        }
        .header{
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: white;
            text-align: center;
            font-size: 24px;
            position: fixed;
            top:0;
            left: 0;
            z-index: 2;
            overflow: hidden;
        }
        .nav-links {
            text-align: center;
            margin-top: 10px;
        }
        .nav-links a {
            color: white;
            padding: 10px;
            text-decoration: none;
            font-size: 16px;
        }
        .nav-links a:hover {
            background-color: #555;
            color: white;
        }

        .center{
            padding-top: 50px;
            max-width: 400px;
            margin: auto;
        }
        .h2{
            ext-align: left;
            color: #333;
        }
        label{
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], select, textarea {
            width: 100%;
            padding: 8px;       
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .right-content {
            padding: 20px;
            top: auto;
        }
        .item-info {
            padding: 10px 0;
            border-bottom: 1px solid #ddd;
        }
        .total {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">WearWhen - Checkout</div>
            <div class="nav-links">
                <nav>
                    <a href="index.html">Home</a>
                    <a href="shop.html">Shop</a>
                    <a href="wishlist.html">Wishlist</a>
                    <a href="profile.html">Profile</a>
                    <a href="cart.html">Cart</a>
                </nav>
            </div>
    </header>
    <div class= "side left">
        <div class="center">
            <h2>Customer Information</h2>
            <form action="cartInsert.php" method="POST">
                <br>
                <br>
                <br>
                <label for="fname">First Name:</label><br>
                <input type="text" id="fname" name="fname" maxlength="20">
                <br><br>

                <label for="lname">Last Name:</label><br>
                <input type="text" id="lname" name="lname" maxlength="20" required><br><br>

                <label for="email">Email:</label><br>
                <input type="email" id="email" name="email" maxlength="50" ><br><br>

                <label for="address">Home Address:</label><br>
                <textarea id="address" name="address" rows="4" maxlength="75" required></textarea><br><br>

                <label for="cardnum">Card Number:</label><br>
                <input type="text" id="cardnum" name="cardnum" maxlength="16" required><br><br>

                <label for="secureCode">Security Code:</label><br>
                <input type="text" id="secureCode" name="secureCode" maxlength="4" required><br><br>

                <label for="phonenum">Phone Number:</label><br>
                <input type="text" id="phonenum" name="phonenum" maxlength="10" required><br><br>


                <label for="sizing">Sizing</label>
                <select id="sizing" name="sizing" required>
                    <option value="M">Mens</option>
                    <option value="W">Womens</option>
                    <option value="K">Kids</option>
                </select>
                <br><br>

                <label for="size">Size</label><br>
                <select id="size" name="size" required>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option> 
                    <option value="4">4</option>
                    <option value="5">5</option> 
                    <option value="6">6</option>
                    <option value="7">7</option> 
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option> 
                    <option value="13">13</option>
                    <option value="14">14</option>
                </select>
                <br><br>

                <?php echo '<input type = "hidden" name="product_id" value="'.$product_id'">';?>
                <?php echo '<input type = "hidden" name="product_price" value="'.$product_price'">';?>

                <button type="submit">Submit</button>
            </form>
        </section>
        </div>
    </div>
    <div class="side right">
        <div class="right-content">
            <h2>Items & Pricing</h2>
            <div class="item-info">
                <p>Shoe ID: <strong>12345</strong></p>
                <p>Price: <strong>$80.00</strong></p>
            </div>
            <div class="item-info">
                <p>Shoe ID: <strong>67890</strong></p>
                <p>Price: <strong>$120.00</strong></p>
            </div>
            <div class="total">
                Total: <strong>$200.00</strong>
            </div>
        </div>
    </div>

    </div>
    <script src="script.js"></script>
</body>
</html>
    