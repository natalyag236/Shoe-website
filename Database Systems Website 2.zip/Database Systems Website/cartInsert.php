<?php

echo "Your input has been submitted <br> ";
echo "______________________________________________________<br>";

$first_name = $_POST["fname"];
echo "Customer's Name: ".$first_name."<br>";

$last_name = $_POST["lname"];
echo "Customer's Last Name: ".$last_name."<br>";

$email = $_POST["email"];
echo "Customer's Email: ".$email."<br>";

$address = $_POST["address"];
echo "Customer's Address: ".$address."<br>";

$shoe_price = $_POST["product_price"];
echo "Price: ".$shoe_price."<br>";

$card_number = $_POST['cardnum'];
echo "Card Number: ".$card_number."<br>";

$security_code = $_POST['secureCode'];
echo "Security Code: ".$security_code."<br>";

$phone_number = $_POST['sizing'];
echo "Phone number: ".$phone_number."<br>";

$shoe_ID = $_POST['sizing'];


$servername = "localhost";
$username = "KW234";
$password = "Ke'niah";
$dbname = "Database_Systems";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$product_id = $_POST['product_id'];
$product_name = $_POST['product_name'];
$price = $_POST['price'];

$sql = "INSERT INTO CHECKOUT (First_name, Last_name, Email, Home_address, Price, Card_number, Security_code, Phone_number, Shoe_ID)
Price) VALUES('$first_name','$last_name','$email','$address','$product_price','$card_number','$security_code','$phone_number','$product_id')";

if ($conn->query($sql) === TRUE) {
    echo "Item added to cart successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>
