<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = htmlspecialchars(trim($_POST["first-name"]));
    $lastName = htmlspecialchars(trim($_POST["last-name"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $homeAddress = htmlspecialchars(trim($_POST["home_address"]));
    $shoeSize = (int) htmlspecialchars(trim($_POST["shoe_size"]));
    $sizingGender = htmlspecialchars(trim($_POST["sizing_gender"]));

    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "root";  // MAMP default for Mac
    $dbname = "Shoes web"; 

    // Create a new connection to the database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check if the connection was successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to insert the customer data into the 'customers' table
    $sql = "INSERT INTO customers (first_name, last_name, email, home_address, shoe_size, sizing_gender) 
            VALUES ('$firstName', '$lastName', '$email', '$homeAddress', $shoeSize, '$sizingGender')";

    // Execute the query and check if it was successful
    if ($conn->query($sql) === TRUE) {
        echo "<h4 style='color: green;'>Customer registered successfully!</h4>";
    } else {
        echo "<h4 style='color: red;'>Error: " . $conn->error . "</h4>";
    }

  
    $conn->close();
}
?>
